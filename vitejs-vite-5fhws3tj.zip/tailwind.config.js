export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx,css}"],
  theme: {
    extend: {
      colors: { neon: "#39FF14" },
    },
  },
  plugins: [],
};